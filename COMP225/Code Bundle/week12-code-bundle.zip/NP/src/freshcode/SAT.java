package freshcode;

public class SAT {

        public static boolean verify(BinArray vars, int cons[][])
        {
                boolean indivResult;
                boolean result = true;
                int term;

                for (int i = 0; i < cons.length; i++) { // check all clauses
                        indivResult = false;
                        for (int j = 0; j < cons[i].length; j++) { // check single clause
                                if (cons[i][j] == 0)
                                        term = 0;
                                else if (cons[i][j] == 1)
                                        term = vars.get(j);
                                else
                                        term = 1 - vars.get(j);
                                indivResult = indivResult || (term == 1); // clause T if one term is T
                        }
                        result = result && indivResult; // result T if all clauses T
                }
                return result;
        }


        public static boolean sat(int cons[][])
        {

                boolean result; // whether we've found a solution

                if (cons.length > 0) { // there are some constraints
                        result = false;
                        BinArray vars = new BinArray(cons[0].length);
                        vars.init();
                        result = verify(vars, cons);
                        while (!result && !vars.isMax()) { // enumerate all candidate solutions 
                                vars.inc();
                                result = verify(vars, cons);
                        }
                        vars.print();
                }
                else
                        result = true;
                return result;
        }

        public static void main(String[] args)
        {
                int n = 4;
                BinArray b = new BinArray(n);
                int[][] cons = {{1, -1, 1, -1},
                                {0, 1, 1, -1},
                                {-1, 0, -1, 1},
                                {0, 1, 1, -1},
                                {1, 1, 1, 0},
                                {-1, 1, 1, 0},
                                {1, 0, 1, 1},
                                {-1, -1, 0, 1}};

                System.out.println("Enumeration of variables:");
                b.init();
                b.print();
                while (!b.isMax()) {
                        b.inc();
                        b.print();
                }

                b.init();

                System.out.println("Printing constraints:");
                for (int i = 0; i < cons.length; i++) {
                        for (int j = 0; j < cons[i].length; j++)
                                System.out.print(cons[i][j] + " ");
                        System.out.println();
                }

                System.out.println("Solution?: " + sat(cons));
        }


}
