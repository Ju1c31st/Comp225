package freshcode;

public class BinArray {

	private int MAXSIZE;
	private int[] a;

	public BinArray(int n) {
		MAXSIZE = n;
		a = new int[MAXSIZE];
		this.init();
	}

	public void init()
	{
		for (int i = 0; i < a.length; i++)
			a[i] = 0;
	}

	public void print()
	{
		for (int i = 0; i < a.length; i++)
			System.out.print(a[i] + " ");
		System.out.println();
	}


	public void inc()
	{
		// TODO
	}

	public boolean isMax()
	{
		// TODO
		
		return false;
	}


	public int get(int j)
	{
		return a[j];
	}

}
